var fs = require('fs');
var http = require('http');

http.createServer((request, responce) => {
  if (request.url != '/favicon.ico') {
    getPage(request.url, responce);
  }
}).listen(8080);

function getPage(name, responce, statusCode = 200) {
  if (name == '/') {
    name = 'index';
  }

  fs.readFile('views/' + name + '.html', (err, data) => {
    if (!err) {
      responce.setHeader('Content-Type', 'text/html');
      responce.statusCode = statusCode;
      responce.write(data);
      responce.end();
    } else {
      if (statusCode != 404) {
        getPage('404', responce, 404);
      } else {
        throw err;
      }
    }
  });
}